#ifndef GRAPH_H
#define GRAPH_H
#include <bits/stdc++.h>
#include "dlist.h"

#define maxn 105
void read_input(Dlist matrix[maxn], int &n);
void write_output(Dlist matrix[maxn], Dlist graph[maxn], const int n);

#endif
